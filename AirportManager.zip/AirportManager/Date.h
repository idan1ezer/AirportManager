#pragma once

#define MIN_YEAR 2020

typedef struct
{
	int			day;
	int			month;
	int			year;
}Date;

void	getCorrectDate(Date* pDate);
int		checkDate(char* date, Date* pDate);
int		isExistDate(const void* d1, const void* d2);
void	printDate(const void* pDate);
char*	toString(Date* pDate, char* date);
int		isBigger(const Date* a, const Date* b);
void	writeDate(Date* pDate, FILE* fComp);
void	readDate(Date* date, FILE* fComp);