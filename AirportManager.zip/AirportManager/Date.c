#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "General.h"
#include "Date.h"

const int DAY_MONTHS[12] = { 31,28,31,30,31,30,31,31,30,31,30,31 };


void getCorrectDate(Date* pDate)
{
	char date[MAX_STR_LEN];
	int ok = 1;

	do {
		puts("Enter Flight Date dd/mm/yyyy\t");
		myGets(date, MAX_STR_LEN);
		ok = checkDate(date, pDate);
		if (!ok)
			printf("Error try again\n");
	} while (!ok);
}


int	 checkDate(char* date, Date* pDate)
{
	int day, month, year;
	if (strlen(date) != 10)
		return 0;
	if ((date[2] != '/') || (date[5] != '/'))
		return 0;
	sscanf(date, "%d/%d/%d", &day, &month, &year);
	if (day < 1 || month < 1 || month > 12 || year < MIN_YEAR)
		return 0;

	if (day > DAY_MONTHS[month - 1])
		return 0;

	pDate->day = day;
	pDate->month = month;
	pDate->year = year;

	return 1;
}

int	isExistDate(const void* d1, const void* d2)
{
	Date* pD1 = (Date*)d1;
	Date* pD2 = (Date*)d2;
	if ((pD1->day == pD2->day) && (pD1->month == pD2->month) && (pD1->year == pD2->year))
		return 0;
	return 1;
}

void printDate(const void* pDate)
{
	Date* pD = (Date*)pDate;
	printf("Date: %d/%d/%d", pD->day, pD->month, pD->year);
}

char*	toString(Date* pDate, char* date)
{
	sprintf(date,"%d/%d/%d", pDate->day,pDate->month,pDate->year);

	return date;
}

int		isBigger(const Date* a, const Date* b)
{
	const Date* pD1 = (const Date*)a;
	const Date* pD2 = (const Date*)b;

	if (pD1->year > pD2->year)
		return 1;
	else if (pD1->year < pD2->year)
		return -1;
	else
	{
		if (pD1->month > pD2->month)
			return 1;
		else if (pD1->month < pD2->month)
			return -1;
		else
		{
			if (pD1->day > pD2->day)
				return 1;
			else if (pD1->day < pD2->day)
				return -1;
			else
				return 0;
		}
	}
}

void	writeDate(Date* pDate, FILE* fComp)
{
	fwrite(&pDate->day, sizeof(int), 1, fComp);
	fwrite(&pDate->month, sizeof(int), 1, fComp);
	fwrite(&pDate->year, sizeof(int), 1, fComp);
}

void	readDate(Date* date, FILE* fComp)
{
	fread(&date->day, sizeof(int), 1, fComp);
	fread(&date->month, sizeof(int), 1, fComp);
	fread(&date->year, sizeof(int), 1, fComp);
}
