#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Flight.h"


void	initFlight(Flight* pFlight, const AirportManager* pManager)
{
	Airport* pPortOr = setAiportToFlight(pManager, "Enter code of origin airport:");
	strcpy(pFlight->originCode, pPortOr->code);
	int same;
	Airport* pPortDes;
	do {
		pPortDes = setAiportToFlight(pManager, "Enter code of destination airport:");
		same = isSameAirport(pPortOr, pPortDes);
		if (same)
			printf("Same origin and destination airport\n");
	} while (same);
	strcpy(pFlight->destCode, pPortDes->code);
	getCorrectDate(&pFlight->date);
	pFlight->hour = getFlightHour();
}

int	isFlightInRoute(const Flight* pFlight, const char* codeSource, const char* codeDest)
{
	if ((strcmp(pFlight->originCode, codeSource) == 0) &&
		(strcmp(pFlight->destCode, codeDest) == 0))
		return 1;

	return 0;
}

int	countFlightsInRoute(Flight** arr, int size, const char* codeSource,
	const char* codeDest)
{
	int count = 0;
	for (int i = 0; i < size; i++)
	{
		if (isFlightInRoute(arr[i], codeSource, codeDest))
			count++;
	}
	return count;
}

void	printFlight(const void* pFlight)
{
	Flight* flight = *(Flight**)pFlight;
	printf("Flight From %s To %s\t", flight->originCode, flight->destCode);
	printDate(&flight->date);
	printf(" Hour: %d\n", flight->hour);
}


int getFlightHour()
{
	int h;
	do {
		printf("Enter flight hour [0-23]:\t");
		scanf("%d", &h);
	} while (h < 0 || h>23);
	return h;
}

Airport* setAiportToFlight(const AirportManager* pManager, const char* msg)
{
	char code[MAX_STR_LEN];
	Airport* port;
	do
	{
		printf("%s\t", msg);
		myGets(code, MAX_STR_LEN);
		port = findAirportByCode(pManager, code);
		if (port == NULL)
			printf("No airport in this country - try again\n");
	} while (port == NULL);

	return port;
}

void	freeFlight(void* pFlight)
{
	Flight* flight = *(Flight**)pFlight;
	free(flight);
}

int		compareFlightsByHour(const void* a, const void* b)
{
	const Flight* pF1 = *(const Flight**)a;
	const Flight* pF2 = *(const Flight**)b;
	
	return (pF1->hour - pF2->hour);
}

int		compareFlightsByDate(const void* a, const void* b)
{
	const Flight* pF1 = *(const Flight**)a;
	const Flight* pF2 = *(const Flight**)b;

	return isBigger(&pF1->date, &pF2->date);
}

int		compareFlightsByOrigin(const void* a, const void* b)
{
	const Flight* pF1 = *(Flight**)a;
	const Flight* pF2 = *(Flight**)b;
	return strcmp(pF1->originCode, pF2->originCode);
}
int		compareFlightsByDest(const void* a, const void* b)
{
	const Flight* pF1 = *(Flight**)a;
	const Flight* pF2 = *(Flight**)b;
	return strcmp(pF1->destCode, pF2->destCode);
}

void	writeFlight(Flight* pFlight, FILE* fComp)
{
	fwrite(pFlight->originCode, sizeof(char), 4, fComp);
	fwrite(pFlight->destCode, sizeof(char), 4, fComp);
	fwrite(&pFlight->hour, sizeof(int), 1, fComp);

	writeDate(&pFlight->date, fComp);
}

void	readFlight(Flight* pFlight, FILE* fComp)
{
	char tempOriginCode[4], tempDestCode[4];
	int hour;

	fread(tempOriginCode, sizeof(char), 4, fComp);
	strcpy(pFlight->originCode, tempOriginCode);
	fread(tempDestCode, sizeof(char), 4, fComp);
	strcpy(pFlight->destCode, tempDestCode);

	fread(&hour, sizeof(int), 1, fComp);
	pFlight->hour = hour;
	readDate(&pFlight->date, fComp);
}