#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "AirportManager.h"

int	initManager(AirportManager* pManager)
{
	printf("-----------  Init airport Manager\n");
	pManager->count = 0;
	if (!L_init(&pManager->apList)) return 0;

	int count = 0;
	do {
		printf("How many airport?\t");
		scanf("%d", &count);
	} while (count < 0);
	//clean buffer
	char tav;
	scanf("%c", &tav);
	if (count == 0)
		return 1;

	for (int i = 0; i < count; i++)
		addAirport(pManager);

	return 1;
}

int	addAirport(AirportManager* pManager)
{
	NODE* pList = &pManager->apList.head;
	Airport* pAP = (Airport*)malloc(sizeof(Airport));
	if (!pAP) return 0;
	setAirport(pAP, pManager);

	if (pManager->count == 0)
	{
		L_insert(pList, pAP);
		pManager->count++;
	}
	else
	{
		for (int j = 0; j < pManager->count; j++)
		{
			if (compareAirportsByIATA(pList->next->key, pAP) < 0)
			{
				L_insert(pList, pAP);
				pManager->count++;
				break;
			}
			pList = pList->next;
		}
	}
	return 1;
}

void  setAirport(Airport* pPort, AirportManager* pManager)
{
	while (1)
	{
		getAirportCode(pPort->code);
		if (checkUniqeCode(pPort->code, pManager))
			break;

		printf("This code already in use - enter a different code\n");
	}
	initAirportNoCode(pPort);
}

Airport* findAirportByCode(const AirportManager* pManager, const char* code)
{
	NODE* pNode = pManager->apList.head.next;

	if (pNode == NULL)
		return NULL;

	while (pNode != NULL)
	{
		if (isAirportCode(pNode->key, code))
			return pNode->key;
		pNode = pNode->next;
	}
	return NULL;
}

int checkUniqeCode(const char* code, const AirportManager* pManager)
{
	Airport* port = findAirportByCode(pManager, code);

	if (port != NULL)
		return 0;

	return 1;
}


void	printAirports(const AirportManager* pManager)
{
	printf("There are %d airports:\n", pManager->count);
	L_print(&pManager->apList, printAirport);
}

void	freeManager(AirportManager* pManager)
{
	L_free(&pManager->apList, freeAirport);
}

int		readManager(AirportManager* pManager)
{
	if (!L_init(&pManager->apList)) return 0;
	FILE* fManager = fopen("airport_authority.txt", "r");
	if (!fManager)
		return 0;

	fscanf(fManager, "%d\n", &pManager->count);
	for (int i = 0; i < pManager->count; i++)
		readAirport(pManager, fManager, i);

	fclose(fManager);
	return 1;
}

int		readAirport(AirportManager* pManager, FILE* fAirport,int i)
{
	NODE* pList = &pManager->apList.head;
	Airport* pAP = (Airport*)malloc(sizeof(Airport));
	if (!pAP) return 0;
	
	char tempName[250], tempCountry[250], tempCode[4];

	fgets(tempName, 255, fAirport);	tempName[strlen(tempName) - 1] = '\0';	fgets(tempCountry, 255, fAirport);	tempCountry[strlen(tempCountry) - 1] = '\0';	fscanf(fAirport, "%s\n", tempCode);	pAP->name = _strdup(tempName);
	pAP->country = _strdup(tempCountry);
	strcpy(pAP->code, tempCode);

	if(i==0)
		L_insert(pList, pAP);

	else if (pList->next != NULL)
	{
		for (int j = 0; j < i; j++)
		{
			if (compareAirportsByIATA(pList->next->key, pAP) > 0)
			{
				L_insert(pList, pAP);
				return 1;
			}
			pList = pList->next;
		}
		L_insert(pList, pAP);
	}
	return 1;
}

int		writeManager(AirportManager* pManager)
{
	NODE* pList = &pManager->apList.head;
	FILE* fManager = fopen("airport_authority.txt", "w");
	if (!fManager)	return 0;
	fprintf(fManager,"%d\n", pManager->count);

	for (int i = 0; i < pManager->count; i++)
	{
		writeAirport(pList->next->key, fManager);
		pList = pList->next;
	}

	fclose(fManager);
		
	return 1;
}