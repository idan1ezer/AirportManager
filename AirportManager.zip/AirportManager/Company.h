#pragma once

#include "Flight.h"
#include "AirportManager.h"

typedef enum
{
	cNotSorted, cSortedByHour, cSortedByDate, cSortedByOrigin, cSortedByDest, cNofOptions
} cSortOptions;

typedef struct
{
	char*		name;
	int			flightCount;
	Flight**	flightArr;
	LList		datesList;
	enum cSortOptions sorted;

}Company;


void	initCompany(Company* pComp);
int		addFlight(Company* pComp, const AirportManager* pManager);
void	addDateToList(Company* pComp, Flight* pFlight);
void	printCompany(const void* pComp);
void	printFlightsCount(const Company* pComp);
void	printFlightArr(Flight** pFlight, int size);
void	freeFlightArr(Flight** arr, int size);
void	freeCompany(Company* pComp);

void	sortFlightsByHour(Company* pComp);
void	sortFlightsByDate(Company* pComp);
void	sortFlightsByOrigin(Company* pComp);
void	sortFlightsByDest(Company* pComp);
void	bSearchFlight(Company* pComp);

int		writeCompany(Company* pComp);
int		readCompany(Company* pComp);