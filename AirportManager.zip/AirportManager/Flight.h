#pragma once

#include "AirportManager.h"
#include "Date.h"
#include "General.h"

typedef struct
{
	char		originCode[CODE_LENGTH + 1];
	char		destCode[CODE_LENGTH + 1];
	int			hour;
	Date		date;
}Flight;

void	initFlight(Flight* pFlight, const AirportManager* pManager);
int		isFlightInRoute(const Flight* pFlight, const char* codeSource, const char* codeDest);
int		countFlightsInRoute(Flight** arr, int size, const char* codeSource, const char* codeDest);
void	printFlight(const void* pFlight);
int		getFlightHour();
Airport* setAiportToFlight(const AirportManager* pManager, const char* msg);

int		compareFlightsByHour(const void* a, const void* b);
int		compareFlightsByDate(const void* a, const void* b);
int		compareFlightsByOrigin(const void* a, const void* b);
int		compareFlightsByDest(const void* a, const void* b);

void	freeFlight(void* pFlight);
void	writeFlight(Flight* pFlight, FILE* fComp);
void	readFlight(Flight* pFlight, FILE* fComp);