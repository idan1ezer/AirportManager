#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Company.h"
#include "Airport.h"
#include "General.h"

void	initCompany(Company* pComp)
{
	printf("-----------  Init Airline Company\n");
	pComp->name = getStrExactName("Enter company name");
	pComp->flightArr = NULL;
	pComp->flightCount = 0;
	L_init(&pComp->datesList);
	pComp->sorted = cNotSorted;
}

int	addFlight(Company* pComp, const AirportManager* pManager)
{
	if (pManager->count < 2)
	{
		printf("There are not enoght airport to set a flight\n");
		return 0;
	}
	pComp->flightArr = (Flight**)realloc(pComp->flightArr, (pComp->flightCount + 1) * sizeof(Flight*));
	if (!pComp->flightArr)
		return 0;
	pComp->flightArr[pComp->flightCount] = (Flight*)calloc(1, sizeof(Flight));
	if (!pComp->flightArr[pComp->flightCount])
		return 0;
	initFlight(pComp->flightArr[pComp->flightCount], pManager);
	addDateToList(pComp, pComp->flightArr[pComp->flightCount]);
	pComp->flightCount++;
	return 1;
}

void printCompany(const void* pComp)
{
	Company* tempComp = (Company*)pComp;
	printf("Company %s:\n", tempComp->name);
	printf("Has %d flights\n", tempComp->flightCount);
	printFlightArr(tempComp->flightArr, tempComp->flightCount);
	L_print(&tempComp->datesList, printDate);
}

void	printFlightsCount(const Company* pComp)
{
	char codeOrigin[CODE_LENGTH + 1];
	char codeDestination[CODE_LENGTH + 1];

	if (pComp->flightCount == 0)
	{
		printf("No flight to search\n");
		return;
	}

	printf("Origin Airport\n");
	getAirportCode(codeOrigin);
	printf("Destination Airport\n");
	getAirportCode(codeDestination);

	int count = countFlightsInRoute(pComp->flightArr, pComp->flightCount, codeOrigin, codeDestination);
	if (count != 0)
		printf("There are %d flights ", count);
	else
		printf("There are No flights ");

	printf("from %s to %s\n", codeOrigin, codeDestination);
}

void	printFlightArr(Flight** pFlight, int size)
{
	generalArrayFunction(pFlight, size, sizeof(Flight*), printFlight);
}


void	freeFlightArr(Flight** arr, int size)
{
	generalArrayFunction(arr, size, sizeof(Flight*), freeFlight);
}

void	freeCompany(Company* pComp)
{
	freeFlightArr(pComp->flightArr, pComp->flightCount);
	free(pComp->flightArr);
	free(pComp->name);
}

void	addDateToList(Company* pComp, Flight* pFlight)
{
	NODE* pList = &pComp->datesList.head;
	NODE* tempDate = NULL;

	if (pList->next == NULL)
		L_insert(pList, &pFlight->date);
	else
	{
		tempDate = L_find(pList->next, &pFlight->date, isExistDate);
		if (tempDate == NULL)
			L_insert(pList, &pFlight->date);
	}
}

void	sortFlightsByHour(Company* pComp)
{
	qsort(pComp->flightArr, pComp->flightCount, sizeof(Flight*), compareFlightsByHour);
	pComp->sorted = cSortedByHour;
}

void	sortFlightsByDate(Company* pComp)
{
	qsort(pComp->flightArr, pComp->flightCount, sizeof(Flight*), compareFlightsByDate);
	pComp->sorted = cSortedByDate;
}

void	sortFlightsByOrigin(Company* pComp)
{
	qsort(pComp->flightArr, pComp->flightCount, sizeof(Flight*), compareFlightsByOrigin);
	pComp->sorted = cSortedByOrigin;
}

void	sortFlightsByDest(Company* pComp)
{
	qsort(pComp->flightArr, pComp->flightCount, sizeof(Flight*), compareFlightsByDest);
	pComp->sorted = cSortedByDest;
}

void	bSearchFlight(Company* pComp)
{
	int hour = 0;
	Date tempDate = { 01,01,2020 };
	Flight temp = { "","",hour,tempDate };
	Flight* pFlight = &temp;
	Flight* foundFlight = NULL;
	char code[MAX_STR_LEN];

	if (pComp->sorted == cNotSorted)
		printf("Flights array is not sorted, can't search for a flight\n");

	else if (pComp->sorted == cSortedByHour)
	{
		pFlight->hour = getFlightHour();
		foundFlight = (Flight**)bsearch(&pFlight, pComp->flightArr, pComp->flightCount, sizeof(Flight*), compareFlightsByHour);
	}	
	else if (pComp->sorted == cSortedByDate)
	{
		getCorrectDate(&pFlight->date);
		foundFlight = (Flight**)bsearch(&pFlight, pComp->flightArr, pComp->flightCount, sizeof(Flight*), compareFlightsByDate);
	}

	else if (pComp->sorted == cSortedByOrigin)
	{
		printf("Enter Origin Code:\t");
		myGets(code, MAX_STR_LEN);
		strcpy(pFlight->originCode, code);
		foundFlight = (Flight**)bsearch(&pFlight, pComp->flightArr, pComp->flightCount, sizeof(Flight*), compareFlightsByOrigin);
	}

	else if (pComp->sorted == cSortedByDest)
	{
		printf("Enter Destination Code:\t");
		myGets(code, MAX_STR_LEN);
		strcpy(pFlight->destCode, code);
		foundFlight = (Flight**)bsearch(&pFlight, pComp->flightArr, pComp->flightCount, sizeof(Flight*), compareFlightsByDest);
	}

	if (foundFlight == NULL)
		printf("Flight not found\n");
	else
	{
		foundFlight = *(Flight**)foundFlight;
		printFlight(&foundFlight);
	}
}

int		writeCompany(Company* pComp)
{
	FILE* fComp = fopen("company.bin", "wb");
	if (!fComp)	return 0;
	int nameLen = strlen(pComp->name) + 1;

	fwrite(&nameLen, sizeof(int), 1, fComp);
	fwrite(pComp->name, sizeof(char), nameLen, fComp);
	fwrite(&pComp->flightCount, sizeof(int), 1, fComp);
	fwrite(&pComp->sorted, sizeof(int), 1, fComp);
	
	for (int i = 0; i < pComp->flightCount; i++)
		writeFlight(pComp->flightArr[i], fComp);
	
	fclose(fComp);

	return 1;
}

int		readCompany(Company* pComp)
{
	FILE* fComp = fopen("company.bin", "rb");
	if (!fComp)	return 0;
	int nameLen;
	L_init(&pComp->datesList);

	fread(&nameLen, sizeof(int), 1, fComp);
	pComp->name = (char*)malloc(sizeof(char) * nameLen);
	if (!pComp->name)
		return 0;
	fread(pComp->name, sizeof(char), nameLen, fComp);
	fread(&pComp->flightCount, sizeof(int), 1, fComp);
	fread(&pComp->sorted, sizeof(int), 1, fComp);

	pComp->flightArr = (Flight**)malloc((pComp->flightCount) * sizeof(Flight*));
	if (!pComp->flightArr)
		return 0;

	for (int i = 0; i < pComp->flightCount; i++)
	{
		pComp->flightArr[i] = (Flight*)malloc(sizeof(Flight));
		readFlight(pComp->flightArr[i], fComp);
		addDateToList(pComp, pComp->flightArr[i]);
	}

	fclose(fComp);

	return 1;
}