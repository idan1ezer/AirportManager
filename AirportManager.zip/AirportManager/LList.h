#pragma once

#include "def.h"

/*** Definitions ***/

// Node
typedef struct node
{
	DATA			key;
	struct node* next;
}NODE;

// List
typedef struct
{
	NODE head;
}LList;


/*** Function prototypes ***/

BOOL L_init(LList* pList);					// create new list

NODE* L_insert(NODE* pNode, DATA Value);	// add new node after *pNode

BOOL L_delete(NODE* pNode, void(*freeFunc)(void*));					// erase node after *pNode

NODE* L_find(NODE* pNode, DATA Value, int(*compare)(const void*, const void*));		// return a pointer to the node 

BOOL L_free(LList* pList, void(*freeFunc)(void*));					// free list memory

int L_print(const LList* pList, void(*print)(const void*));					// print the list content