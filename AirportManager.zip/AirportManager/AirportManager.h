#pragma once

#include "Airport.h"
#include "LList.h"

typedef struct
{
	LList		apList;
	int			count;
}AirportManager;

int		initManager(AirportManager* pManager);
int		addAirport(AirportManager* pManager);
void	setAirport(Airport* pPort, AirportManager* pManager);
Airport* findAirportByCode(const AirportManager* pManager, const char* code);
int		checkUniqeCode(const char* code, const AirportManager* pManager);
void	printAirports(const AirportManager* pManager);
void	freeManager(AirportManager* pManager);

int		readManager(AirportManager* pManager);
int		readAirport(AirportManager* pManager, FILE* fAirport, int i);
int		writeManager(AirportManager* pManager);