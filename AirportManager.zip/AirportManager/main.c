///////// Idan Ezer /////////
///////// 315963660 /////////

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include "Company.h"
#include "AirportManager.h"
#include "General.h"

typedef enum
{
	eAddFlight, eAddAirport, ePrintCompany, ePrintAirports,
	ePrintFlightOrigDest, eSorts, eFindFlight, eNofOptions
} eMenuOptions;

const char* str[eNofOptions] = { "Add Flight", "Add Airport",
								"PrintCompany", "Print all Airports",
								"Print flights between origin-destination", "Sort flights by: ","Find flight"};

typedef enum
{
	cSortByHour, cSortByDate, cSortByOrigin, cSortByDest, cSortNofOptions
} eSortsOption;

const char* strSorts[cSortNofOptions] = {"Sort by hour", "Sort by date", "Sort by origin", "Sort by destination" };

#define EXIT			-1
int menu();

int main()
{
	AirportManager	manager;
	Company			company;

	if (!readManager(&manager))
	{
		initManager(&manager);
		initCompany(&company);
	}
		
	else if(!readCompany(&company))
		initCompany(&company);
	

	int option,sortOp;
	int stop = 0, stopSort = 0;

	do
	{
		option = menu();
		switch (option)
		{
		case eAddFlight:
			if (!addFlight(&company, &manager))
				printf("Error adding flight\n");
			break;


		case eAddAirport:
			if (!addAirport(&manager))
				printf("Error adding airport\n");
			break;

		case ePrintCompany:
			printCompany(&company);
			break;

		case ePrintAirports:
			printAirports(&manager);
			break;

		case ePrintFlightOrigDest:
			printFlightsCount(&company);
			break;

		case eSorts:
			do
			{
				sortOp = sortMenu();
				switch (sortOp)
				{
				case cSortByHour:
					sortFlightsByHour(&company);
					break;
				case cSortByDate:
					sortFlightsByDate(&company);
					break;
				case cSortByOrigin:
					sortFlightsByOrigin(&company);
					break;
				case cSortByDest:
					sortFlightsByDest(&company);
					break;
				case EXIT:
					stopSort = 1;
					break;
				default:
					printf("Wrong option\n");
					break;
				}
			} while (!stopSort);			
			break;

		case eFindFlight:
			bSearchFlight(&company);
			break;

		case EXIT:
			printf("Bye bye\n");
			stop = 1;
			break;

		default:
			printf("Wrong option\n");
			break;
		}
	} while (!stop);

	writeManager(&manager);
	writeCompany(&company);

	freeManager(&manager);
	freeCompany(&company);
	return 1;
}

int menu()
{
	int option;
	printf("\n\n");
	printf("Please choose one of the following options\n");
	for (int i = 0; i < eNofOptions; i++)
		printf("%d - %s\n", i, str[i]);
	printf("%d - Quit\n", EXIT);
	scanf("%d", &option);
	//clean buffer
	char tav;
	scanf("%c", &tav);
	return option;
}

int sortMenu()
{
	int option;
	printf("\n\n");
	printf("Please choose the type of sort\n");
	for (int i = 0; i < cSortNofOptions; i++)
		printf("%d - %s\n", i, strSorts[i]);
	printf("%d - Quit\n", EXIT);
	scanf("%d", &option);
	//clean buffer
	char tav;
	scanf("%c", &tav);
	return option;
}
